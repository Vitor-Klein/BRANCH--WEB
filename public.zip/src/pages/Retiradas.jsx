function Retiradas() {
    return <h2>Página de Retiradas</h2>;
  }
  export default Retiradas;
  