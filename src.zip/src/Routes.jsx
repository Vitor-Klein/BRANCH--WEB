import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./pages/Home/index";
import Estoque from "./pages/Estoque/Estoque_M";
import CriarItem from "./pages/Estoque/CriarItem";

export function AppRoutes() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/estoque" element={<Estoque />} />
        <Route path="/criarItem" element={<CriarItem />} />
      </Routes>
    </Router>
  );
}
